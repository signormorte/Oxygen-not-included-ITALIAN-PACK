Grazie per aver scaricato il pacchetto lingua Italiano, Per installarlo ti basta mettere i file presenti nel download nella cartella
Oxygen Not Included\OxygenNotIncluded_Data\StreamingAssets\strings tranne il file readME che non serve per la traduzione del gioco.

Se vuoi sostenere il mio progetto puoi fare una donazione qui: https://www.paypal.me/mrmorte